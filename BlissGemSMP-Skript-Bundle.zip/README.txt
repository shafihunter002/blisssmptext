BlissGem SMP - Skript Bundle
Target: Minecraft Java 1.21.11

Required:
- Skript
- SkBee (for item model syntax)
- Paper/Spigot 1.21.11 compatible server

Resource pack SHA-1:
c5515c74525d06a21353c6dd62264b4632258b83

The server resource-pack setting needs a PUBLIC DIRECT HTTPS URL to the ZIP.
After uploading the ZIP to a direct-download host, put that URL in server.properties:
resource-pack=<DIRECT_HTTPS_URL>
resource-pack-sha1=c5515c74525d06a21353c6dd62264b4632258b83
require-resource-pack=true

Then restart the server.

Script file:
plugins/Skript/scripts/blissgems.sk

Load it with:
/sk reload blissgems
